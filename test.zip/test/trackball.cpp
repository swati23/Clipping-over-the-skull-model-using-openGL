/* trackball.c                               */
/* -----------                               */
/*                                           */
/* Code to implement a simple trackball-like */
/*     motion control.                       */
/*                                           */
/* This expands on Ed Angel's trackball.c    */
/*     demo program.  Though I think I've    */
/*     seen this code (trackball_ptov)       */
/*     before elsewhere.                     */
/*********************************************/

#include<Windows.h>
#include "trackball.h"
#include <glut.h>
#include <math.h>

#ifndef M_PI
#define M_PI            3.14159265358979323846
#endif 


/* sets the size of the window the trackball assumes */
void Trackball::ResizeTrackballWindow( int width, int height )
{
	ballWidth = width;
	ballHeight = height;
}

/* the internal code which computes the rotation */
void Trackball::trackball_ptov(int x, int y, int width, int height, float v[3])
{
    float d, a;

    /* project x,y onto a hemi-sphere centered within width, height */
    v[0] = (2.0F*x - width) / width;
    v[1] = (height - 2.0F*y) / height;
    d = (float) sqrt(v[0]*v[0] + v[1]*v[1]);
    v[2] = (float) cos((M_PI/2.0F) * ((d < 1.0F) ? d : 1.0F));
    a = 1.0F / (float) sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
    v[0] *= a;
    v[1] *= a;
    v[2] *= a;
}

void Trackball::SetTrackballOnClick( int x, int y )
{
	trackball_ptov( x, y, ballWidth, ballHeight, lastPos );
	currentlyTracking = 1;
}

void Trackball::UpdateTrackballOnMotion( int x, int y )
{
	float curPos[3], dx, dy, dz, angle, axis[3];
	if (!currentlyTracking) return;

	trackball_ptov( x, y, ballWidth, ballHeight, curPos );
    dx = curPos[0] - lastPos[0];
	dy = curPos[1] - lastPos[1];
	dz = curPos[2] - lastPos[2];
	if ( fabs(dx) > 0 || fabs(dy) > 0 || fabs(dz) > 0 )
	{
		angle = 90 * sqrt( dx*dx + dy*dy + dz*dz );
		axis[0] = lastPos[1]*curPos[2] - lastPos[2]*curPos[1];
		axis[1] = lastPos[2]*curPos[0] - lastPos[0]*curPos[2];
		axis[2] = lastPos[0]*curPos[1] - lastPos[1]*curPos[0];
		lastPos[0] = curPos[0];
		lastPos[1] = curPos[1];
		lastPos[2] = curPos[2];
		glPushMatrix();
		glLoadIdentity();
        glRotatef( angle, axis[0], axis[1], axis[2] );
		glMultMatrixf( trackballMatrix );
		glGetFloatv( GL_MODELVIEW_MATRIX, trackballMatrix );
		matInvert( trackballMatrix, inverseTrackballMatrix );
		glPopMatrix();
	}
}

Trackball::Trackball( int width, int height )
{
	ballWidth = width; 
	ballHeight = height;
	lastPos[0] = lastPos[1] = lastPos[2] = 0; 
	matIdentity( trackballMatrix ); 
	matIdentity( inverseTrackballMatrix ); 
	currentlyTracking = 0;
}

void Trackball::ResetTrackball( void )
{
	lastPos[0] = lastPos[1] = lastPos[2] = 0; 
	matIdentity( trackballMatrix ); 
	matIdentity( inverseTrackballMatrix ); 
}

void Trackball::MultiplyTrackballMatrix( void )
{
	glMultMatrixf( trackballMatrix );
}

void Trackball::PrintTrackballMatrix( void )
{
	printf("Trackball Matrix:\n" );
	printf("%f %f %f %f\n", trackballMatrix[0], trackballMatrix[4], trackballMatrix[8], trackballMatrix[12] );
	printf("%f %f %f %f\n", trackballMatrix[1], trackballMatrix[5], trackballMatrix[9], trackballMatrix[13] );
	printf("%f %f %f %f\n", trackballMatrix[2], trackballMatrix[6], trackballMatrix[10], trackballMatrix[14] );
	printf("%f %f %f %f\n", trackballMatrix[3], trackballMatrix[7], trackballMatrix[11], trackballMatrix[15] );
}


void Trackball::MultiplyTransposeTrackballMatrix( void )
{
#ifdef GL_VERSION_1_3
	glMultTransposeMatrixf( trackballMatrix );
#else
	float tmpMatrix[16];
	matTranspose( tmpMatrix, trackballMatrix );
	glMultMatrixf( tmpMatrix );
#endif
}

void Trackball::MultiplyInverseTrackballMatrix( void )
{
	glMultMatrixf( inverseTrackballMatrix );
}

void Trackball::MultiplyInverseTransposeTrackballMatrix( void )
{
#ifdef GL_VERSION_1_3
	glMultTransposeMatrixf( trackballMatrix );
#else
	float tmpMatrix[16];
	matTranspose( tmpMatrix, trackballMatrix );
	glMultMatrixf( tmpMatrix );
#endif
}

void Trackball::SetTrackballMatrixTo( GLfloat *newMat )
{
	glPushMatrix();
	glLoadIdentity();
	glMultMatrixf( newMat );
	glGetFloatv( GL_MODELVIEW_MATRIX, trackballMatrix );
	matInvert( trackballMatrix, inverseTrackballMatrix );
	glPopMatrix();
}

void Trackball::GetTrackBallMatrix( GLfloat *matrix )
{
	int i;
	for (i=0;i<16;i++) matrix[i] = trackballMatrix[i];
}


/***************************************************
** A couple matrix functions that are useful      **
***************************************************/


void Trackball::matIdentity(float m[16])
{
    m[0+4*0] = 1; m[0+4*1] = 0; m[0+4*2] = 0; m[0+4*3] = 0;
    m[1+4*0] = 0; m[1+4*1] = 1; m[1+4*2] = 0; m[1+4*3] = 0;
    m[2+4*0] = 0; m[2+4*1] = 0; m[2+4*2] = 1; m[2+4*3] = 0;
    m[3+4*0] = 0; m[3+4*1] = 0; m[3+4*2] = 0; m[3+4*3] = 1;
}

void Trackball::matTranspose(float res[16], float m[16])
{
  res[0] = m[0]; res[4] = m[1]; res[8] = m[2]; res[12] = m[3];
  res[1] = m[4]; res[5] = m[5]; res[9] = m[6]; res[13] = m[7];
  res[2] = m[8]; res[6] = m[9]; res[10] = m[10]; res[14] = m[11];
  res[3] = m[12]; res[7] = m[13]; res[11] = m[14]; res[15] = m[15];
}

int Trackball::matInvert(float src[16], float inverse[16])
{
    float t;
    int i, j, k, swap;
    float tmp[4][4];

    matIdentity(inverse);

    for (i = 0; i < 4; i++) {
	for (j = 0; j < 4; j++) {
	    tmp[i][j] = src[i*4+j];
	}
    }

    for (i = 0; i < 4; i++) {
        /* look for largest element in column. */
        swap = i;
        for (j = i + 1; j < 4; j++) {
            if (fabs(tmp[j][i]) > fabs(tmp[i][i])) {
                swap = j;
            }
        }

        if (swap != i) {
            /* swap rows. */
            for (k = 0; k < 4; k++) {
                t = tmp[i][k];
                tmp[i][k] = tmp[swap][k];
                tmp[swap][k] = t;

                t = inverse[i*4+k];
                inverse[i*4+k] = inverse[swap*4+k];
                inverse[swap*4+k] = t;
            }
        }

        if (tmp[i][i] == 0) {
            /* no non-zero pivot.  the matrix is singular, which
	       shouldn't happen.  This means the user gave us a bad
	       matrix. */
            return 0;
        }

        t = tmp[i][i];
        for (k = 0; k < 4; k++) {
            tmp[i][k] /= t;
            inverse[i*4+k] /= t;
        }
        for (j = 0; j < 4; j++) {
            if (j != i) {
                t = tmp[j][i];
                for (k = 0; k < 4; k++) {
                    tmp[j][k] -= tmp[i][k]*t;
                    inverse[j*4+k] -= inverse[i*4+k]*t;
                }
            }
        }
    }
    return 1;
}

void Trackball::matInverseTranspose( float res[16], float m[16] )
{
  float inv[16];
  matInvert( m, inv );
  matTranspose( res, inv );
}

