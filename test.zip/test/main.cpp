
#include<Windows.h>
#include <time.h>
#include <GL/glew.h>
#include "glutfun.h"
#include "glm.h"
#include<glm/glm.hpp>
#include<glm/gtc/type_ptr.hpp>
#include <vector>
#include<tuple>
#include <math.h>
#include "trackball.h"
#include "materials.h"
#include<glut.h>
#include<iostream>
using namespace std;

//#include "common\shader.hpp"

#define PI 3.14159
bool depth = false;

#define _CRT_SECURE_NO_DEPRECATE

int screen_width = 640, screen_height = 480;
float aspect = (float)screen_width/screen_height;
GLMmodel *model[5];
Trackball *ball = new Trackball( screen_width, screen_height ); 
Trackball *ball1 = new Trackball( screen_width, screen_height ); 

// file name for each model
char *ModelName[5] = {"skull.obj","bunny.obj", "dragon_10k.obj", "teapot.obj", "cow.obj"};
int ModelID = 0;
int MaterialID = 0;
bool isal = true;
bool ismaton = false;
bool ismovinglight = false;

glm::mat4 mv, p, inv;
float* pointTo_mv;
float* pointTo_p;
glm::vec4 mouseCoord_Normalized(1,1,1,1);
glm::vec4 mouse_3DClick;


typedef std::tuple<float, float, float, float> temp;
std::vector<temp> clickPoints;
temp t1;
pair<float, float> tempPoints;
GLdouble v[] = { 0, 0, -1, -2 };

/***************************************************
** display function -- what to draw               **
***************************************************/
void display ( void )
{

	/* display stuff... */

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); 
	
	glLoadIdentity(); 

	float light_position[] = {0.0, 0.0, 1.0, 0.0};

	glMatrixMode(GL_MODELVIEW);

	// bind to clip plane
	glClipPlane(GL_CLIP_PLANE0, v);
	// enabled it
	glEnable(GL_CLIP_PLANE0);


    gluLookAt(0.0, 0.0, 2.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);


	ball->MultiplyTrackballMatrix();

	glPushMatrix();

	ball1->MultiplyTrackballMatrix();
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);	

//	glTranslatef(0.0,0.0,1.0);
//	glutSolidSphere(0.1,10,8);
	glPopMatrix();
	glmDraw( model[ModelID], GLM_SMOOTH | GLM_MATERIAL );

	glColor3f(1.0f, 0.0f, 0.0f);
	glPointSize(5.0f);
	glBegin(GL_POINTS);

	for (temp t : clickPoints)
	{
		glVertex3f(get<0> (t), get<1> (t), get<2> (t));
	}

	glEnd();
	


	/* flush GL commands & swap buffers */
	glDisable(GL_CLIP_PLANE0);
	
	glFlush();
	glutSwapBuffers();

}

/***************************************************
** idle function... what to do when bored         **
***************************************************/
void idle ( void )
{

	glutPostRedisplay();
}

/***************************************************
** deal with user resizing window (BAD USER!)     **
***************************************************/
void reshape( int w, int h )
{
	/* width & height don't change */
	glViewport(0,0,screen_width,screen_height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(90.0, aspect, 1.0, 100.0);
	glMatrixMode(GL_MODELVIEW);

	ball->ResizeTrackballWindow( screen_width,screen_height );
	ball1->ResizeTrackballWindow( screen_width,screen_height );


}


/***************************************************
** deal with mouse movement                       **
***************************************************/
void motion(int x, int y)
{ 
	ball->UpdateTrackballOnMotion(x,y);
	ball1->UpdateTrackballOnMotion(x,y);

}

/***************************************************
** deal with mouse clicks                         **
***************************************************/
void button(int b, int st, int x, int y)
{
	
	//float mv[4][4], p[4][4];
	//GLubyte pixel;
	
	switch (b)
	{
	default:
		break;

	case GLUT_LEFT_BUTTON:
	{
		switch (st)
		{
		case GLUT_DOWN:
			//partB virtual trackball


			ball->SetTrackballOnClick(x, y);
			v[3] += 0.1;
			
			//calculating inverse of model-view-projection matrix
			pointTo_p = glm::value_ptr(p);
			pointTo_mv = glm::value_ptr(mv);
			glGetFloatv(GL_MODELVIEW_MATRIX, pointTo_mv);
			glGetFloatv(GL_PROJECTION_MATRIX, pointTo_p);
			inv = (mv*p)._inverse();

			//Normalizing window coordinates to [-1,1] range
			GLint vp[4];
			glGetIntegerv(GL_VIEWPORT, vp);
			mouseCoord_Normalized[0] = 1.0f-2.0f * ((float)(x - vp[0]) / (float)(vp[2]));
			mouseCoord_Normalized[1] = 2.0f * ((float)(y -vp[1]) / (float)(vp[3])) - 1.0f;
			//glReadPixels(x, int(y), 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &mouseCoord_Normalized[2]);
			mouseCoord_Normalized[2] = 0.0;
			mouseCoord_Normalized[3] = 1.0f;
			
			clickPoints.push_back(t1);

			cout << x << "   " << y << endl;

			mouse_3DClick = inv * mouseCoord_Normalized;
			mouse_3DClick[3] = 1.0 / mouse_3DClick[3];
			mouse_3DClick[0] = mouse_3DClick[0] * mouse_3DClick[3];
			mouse_3DClick[1] = mouse_3DClick[1] * mouse_3DClick[3];
			mouse_3DClick[2] = mouse_3DClick[2] * mouse_3DClick[3];

			//assigning coordinates to temporary tuple
			get<0>(t1) = mouse_3DClick[0];
			get<1>(t1) = mouse_3DClick[1];
			get<2>(t1) = mouse_3DClick[2];
			get<3>(t1) = mouse_3DClick[3];
			
			/*mouse_3DClick.x /= mouse_3DClick.w;
			mouse_3DClick.y /= mouse_3DClick.w;
			mouse_3DClick.z /= mouse_3DClick.w;
			mouse_3DClick.w = 1.0f;
			*/

			for (int i = 0; i < 4; i++)
			{
				cout <<mouse_3DClick[i] << " ";
				if (i == 3)
					cout << endl;
			}

			


			break;
		case GLUT_UP:

			ball->ReleaseTrackball();
			break;
		}
	}
		break;
	case GLUT_MIDDLE_BUTTON:
	{
		switch (st)
		{
		case GLUT_DOWN:
			ismovinglight = true;
			ball1->SetTrackballOnClick(x, y);
			v[3] -= 0.1;
			break;
		case GLUT_UP:
			ismovinglight = false;
			ball1->ReleaseTrackball();
			break;
		}
	}
		break;
	case GLUT_RIGHT_BUTTON:
	{
			switch (st)
			{
			case GLUT_DOWN:
				//			printf("Right Button clicked at [%d %d]\n", x ,screen_height -1  - y);
				break;
			case GLUT_UP:
				//		printf("Right Button released at [%d %d]\n", x,y);
				break;
			}
	}
		break;
	}
		/* can do right button too...  unless there's a menu! */

	
	//glutPostRedisplay();
}

void UpdateMaterialType(int m_id)
{

	glLightfv(GL_LIGHT0, GL_AMBIENT, mat[m_id].ambient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE,  mat[m_id].diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR,  mat[m_id].specular);
	glMaterialfv(GL_FRONT, GL_SHININESS, &mat[m_id].shiny);
}



/***************************************************
** deal with menu commands                        **
***************************************************/
void menu( int value )
{
	switch (value) 
	{
	default:
		break;
	case 200:  // User selected menu item "skull model".  Deal with it!
		ModelID = 0;

		break;
	case 201:  // User selected menu item "Bunny".  Deal with it!
		ModelID = 1;

		break;
	case 202:  // User selected menu item "Dragon".  Deal with it!
		ModelID = 2;

		break;
	case 203:  // User selected menu item " Teapot".  Deal with it!
		ModelID = 3;

		break;
	case 204:  // User selected menu item "Cow".  Deal with it!
		ModelID = 4;

		break;
	case 300:  // User selected menu item "Brass".  Deal with it!
		MaterialID = 0;

		UpdateMaterialType(MaterialID);
		break;
	case 301:  // User selected menu item "Pewter".  Deal with it!
		MaterialID = 8;

		UpdateMaterialType(MaterialID);

		break;
	case 302:  // User selected menu item "Emerald".  Deal with it!
		MaterialID = 11;

		UpdateMaterialType(MaterialID);

		break;
	case 303:  // User selected menu item "gold".  Deal with it!
		MaterialID = 6;
		UpdateMaterialType(MaterialID);

		break;
	case 27:   // User selected "Quit"!
		exit(0);
		break;
	}

	glutPostRedisplay();

}

/***************************************************
** deal with key strokes                          **
***************************************************/
void keys(unsigned char key, int x, int y)
{
	switch ( key )
	{
	default:
		break;
	case 'Q':
	case 'q':
	case 'c':
	case 'd': depth = !depth;

		if (depth)
			printf("Enable GL_DEPTH_TEST\n");
		else
			printf("Disable GL_DEPTH_TEST\n");
		/* quit! */
		break;
	}

}

/***************************************************
** extract the parameters from the command line   **
***************************************************/
void ExtractCommandLineParameters( int argc, char **argv )
{
	int i;

	printf("\n");

	/* while there are parameters to deal with */
	for ( i = 1; i < argc; i++ )
	{
		if (!strcmp(argv[i], "-help"))
		{
			printf("Usage:  %s [options] \n\n", argv[0]);
			printf("Options:\n");
			printf("\t-help            Print this message and exit\n");
			printf("\t-debug           Print dubugging messages during execution\n");

			exit(0);
		}
		if (!strcmp(argv[i], "-d") || !strcmp(argv[i], "-debug"))
		{
			/* put debug switches here */	  
			i++;
		}

	}
}



/***************************************************
** init                                           **
***************************************************/
void init(void)
{

	glClearColor(0.0, 0.0, 0.0, 0.0);
	glClearDepth(1.0);


	// looad all models

	for(int i=0; i<5; i++)
	{
		model[i] = glmReadOBJ( ModelName[i] );
		glmUnitize( model[i] );
		glmFacetNormals( model[i] );
		glmVertexNormals( model[i], 90.0 );
	}

	float light_ambient[] = {0.4, 0.4, 0.4, 1.0}; 
	float light_diffuse[] = {1.5, 1.5, 1.5, 1.0};
	float light_specular[] = {1.0, 1.0, 1.0, 1.0};
	float light_position[] = {0.0, 0.0, 1.0, 0.0};

	glClearColor (1.0, 1.0, 0.0, 0.0); 	// clear background into black

	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_NORMALIZE); /* Normalize normals */
	 
	glShadeModel(GL_SMOOTH);

}
/***************************************************
** main entry point                               **
***************************************************/

int main(int argc, char** argv)
{
	GLint objMenu, matlMenu;



	/* Do all the general purpose startup stuff...*/
	glutInit(&argc, argv);

	/* get command line parameters */
	ExtractCommandLineParameters( argc, argv );

	/* we got a RGBA buffer and we're double buffering! */
	glutInitDisplayMode( GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH );

	/* set some size for the window. */
	glutInitWindowSize( screen_width, screen_height );

	/* arbitrarily set an initial window position... */
	glutInitWindowPosition( 100, 100 );

	/* make the window.  give it a cool title */
	glutCreateWindow("GLUT");
	init();

	// Create and compile our GLSL program from the shaders
	//GLuint programID = LoadShaders("SimpleVertexShader.vertexshader","SimpleGeometryShader.geometryshader", "SimpleFragmentShader.fragmentshader");
	// Get a handle for our "MVP" uniform
		//GLuint MatrixID = glGetUniformLocation(programID, "MVP");
	//GLuint ViewMatrixID = glGetUniformLocation(programID, "V");
	//GLuint ModelMatrixID = glGetUniformLocation(programID, "M");



	/* set the callback functions */
	glutDisplayFunc( display );
	glutReshapeFunc( reshape );
	glutIdleFunc( idle );
	glutMouseFunc( button );
	glutMotionFunc( motion );
	glutKeyboardFunc( keys );


	/* setup the menu */
	/* probably will do something here eventually... */
	/* Object Menu */	

	objMenu = glutCreateMenu( menu );
	glutAddMenuEntry("skull model", 200);
	glutAddMenuEntry("Bunny", 201);
	glutAddMenuEntry("Dragon", 202);
	glutAddMenuEntry("Teapot", 203);
	glutAddMenuEntry("Cow", 204);
	/* Material menu */
	matlMenu = glutCreateMenu( menu );
	glutAddMenuEntry("Brass", 300);        //  <--- the number is the value passed to the menu callback
	glutAddMenuEntry("Pewter", 301);
	glutAddMenuEntry("Emerald", 302);
	glutAddMenuEntry("gold", 303);

	/* Main menu */
	glutCreateMenu( menu );  
	glutAddSubMenu("Object Selection", objMenu );
	glutAddSubMenu("Material Selection", matlMenu );
	glutAddMenuEntry(" ", 0 );
	glutAddMenuEntry("Quit", 27);
	glutAttachMenu(GLUT_RIGHT_BUTTON);  // attaches the current menu to the right button 
	//   (the current one is the last one created!)


	std::cout << "Fine" << std::endl;
	/* start it! */
	glutMainLoop();
	return 0;
}

