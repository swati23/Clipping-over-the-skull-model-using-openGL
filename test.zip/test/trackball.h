/*********************************************************/
/* trackball.h                                           */
/* -----------                                           */
/*                                                       */
/* Defines a simple, easy-to-use trackball class which   */
/*    converts motion on a 2D window into 3D rotations.  */
/*                                                       */
/*    Initialization:                                    */
/*    ---------------                                    */
/*    Trackball *ball = new Trackball( windowWidth,      */
/*                                     windowHeight );   */
/*                                                       */
/*    If window is resized:                              */
/*    ---------------------                              */
/*    ball->ResizeTrackballWindow( newWidth,newHeight ); */
/*                                                       */
/*    When mouse button is pressed:                      */
/*    -----------------------------                      */
/*    ball->SetTrackballOnClick( currentMousePosX,       */
/*                               currentMousePosY );     */
/*                                                       */
/*    Upon mouse movement (with button pressed):         */
/*    ------------------------------------------         */
/*    ball->UpdateTrackballOnMotion( currentMousePosX,   */
/*                                   currentMousePosY ); */
/*                                                       */
/*    When mouse button is released:                     */
/*    ------------------------------                     */
/*    ball->ReleaseTrackball();                          */
/*                                                       */
/*    Using the trackball matrix: (This is cumulative,   */
/*       and includes all mouse movements so far!)       */
/*    ------------------------------------------------   */
/*    ball->MultiplyTrackballMatrix(); // onto GL stack! */
/*    (or)                                               */
/*    float matrix[16]; // a GL-style matrix             */           
/*    ball->GetTrackballMatrix( &matrix );               */
/*                                                       */
/*                                                       */
/* */
/*********************************************************/
/*                                                       */                  
/* NOTES:                                                */
/*   -- Platform independent.                            */
/*   -- Uses GLUT to get platform independence.  This    */
/*      means <GL/glut.h> is included in the .cpp file,  */
/*      but no GLUT function calls are used.             */
/*   -- If you do not have GLUT, you may change the      */
/*      trackball.cpp to #include <GL/gl.h> instead of   */
/*      #include <GL/glut.h>                             */
/*                                                       */
/*********************************************************/


#ifndef TRACKBALL_H
#define TRACKBALL_H

#include <stdio.h>
#include <stdlib.h>

class Trackball 
{
	public:

	/* sets up a trackball with window size of width x height */
	Trackball( int width, int height );
	~Trackball();

	/* functions for updating the trackball due to mouse input.           */
	/*    x & y are the window coordinates of the current mouse position. */
	void SetTrackballOnClick( int x, int y );
	void UpdateTrackballOnMotion( int x, int y );
	inline void ReleaseTrackball( void ) { currentlyTracking = 0; }

	/* the computations rely on a width and height of the window (for expected operation) */
	void ResizeTrackballWindow( int width, int height );

	/* calls to multiply the trackball's matrix onto the current GL stack.   */
	void MultiplyTrackballMatrix( void );
	void MultiplyInverseTrackballMatrix( void );
	void MultiplyTransposeTrackballMatrix( void );
	void MultiplyInverseTransposeTrackballMatrix( void );

	/* calls to get or set the value of the trackball */
	void GetTrackBallMatrix( float *matrix );
	void SetTrackballMatrixTo( float *newMat );

	/* call to print to standard out the matrix values. */
	void PrintTrackballMatrix( void );

	/* if the trackball needs to be reset... */
	void ResetTrackball( void );



private:
	int currentlyTracking;
	int ballWidth, ballHeight;
	float lastPos[3]; 
	float trackballMatrix[16]; 
	float inverseTrackballMatrix[16]; 

	void trackball_ptov(int x, int y, int width, int height, float v[3]);
	int matInvert(float src[16], float inverse[16]);
	void matIdentity(float m[16]);
	void matTranspose(float res[16], float m[16]);
	void matInverseTranspose( float res[16], float m[16] );

};



#endif
